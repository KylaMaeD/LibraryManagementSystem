package com.mycompany.librarymanagementsystem;

/*
 *  LOG IN CREDENTIALS
 *  username: engr_cimacio
 *  password: sanamakapasa
 *
 */

public class LibraryManagementSystem {

    public static void main(String[] args) {
        // Create an instance of the Main class to open the program.
        new Main().setVisible(true);
        
        // Indicator that the program compiled properly.
        System.out.println("Hello World!");
    }
}
